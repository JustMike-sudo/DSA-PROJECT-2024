/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.phonebookproject;

/**
 *
 * @author katup
 */
import java.util.Scanner;

public class PhoneBookProject {

    public static void main(String[] args) {
        
    }
}
